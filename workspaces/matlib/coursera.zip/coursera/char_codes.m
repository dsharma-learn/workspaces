function char_codes 
    for ii=33:126
        fprintf('%s', char(ii));
    end
end 