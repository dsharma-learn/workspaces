% This is function that doesnt have any input our output arguments
function myRandNoParam
    a = 1 + rand(3,4)*9
end  