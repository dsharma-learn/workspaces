function Out_mat = top_right (N, n)
    Out_mat = N (1:n, end-n+1:end );
end     