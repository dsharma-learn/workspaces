function v = flip_it_ans (v)
    v = v(end:-1:1);
end