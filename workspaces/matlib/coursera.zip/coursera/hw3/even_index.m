function OutMat = even_index (M) 
    OutMat = M (2:2:end, 2:2:end);
end 