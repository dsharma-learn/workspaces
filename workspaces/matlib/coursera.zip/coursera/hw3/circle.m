function [area, cf] = circle (r)
    area = pi*r*r;
    cf = 2*pi*r;
    