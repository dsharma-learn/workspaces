function w = flip_it (v)
    w = v(end:-1:1)
end    