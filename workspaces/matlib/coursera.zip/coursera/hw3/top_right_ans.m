function A = top_right_ans(A,n)
    A = A(1:n,end-n+1:end);
end