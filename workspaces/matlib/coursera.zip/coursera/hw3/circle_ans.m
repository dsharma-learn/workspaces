function [area, cf] = circle_ans(r)
    area = r.^2 * pi;
    cf = 2 * r * pi;
end