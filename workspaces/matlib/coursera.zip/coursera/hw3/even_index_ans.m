function E = even_index_ans(A)
    E = A(2:2:end,2:2:end);
end