function [t m] = light_speed_ans(km)
    t = km / 3e5 / 60;
    m = km / 1.609;
end