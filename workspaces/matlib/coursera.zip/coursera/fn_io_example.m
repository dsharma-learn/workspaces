function a = fn_io_example 
    x = input ('Please provide an input: '); % NOTE THAT THE STRING IS IN SINGLE QUOTES
    a = x+1;