function s = corner_sum (A)
    s = A(1,1) + A (1,end) + A(end,1) + A (end,end);
    