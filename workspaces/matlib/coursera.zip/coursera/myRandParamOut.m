% Note that in the following function, a in function definition line is same as line where 
% a value is being assinged to a. If it isnt assigned a value, an error is thrown.
function a = myRandParamOut
    a = 1 + rand(3,4)*9
end   

 
